import React from 'react'
import Quiz from './components/Quiz/Quiz'

const App = () => {
  return (
    <div>
      <Quiz/>
    </div>
  )
}

export default App