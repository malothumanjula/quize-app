export const data=[
    {
        question: "Who was the first woman to become President of India?",
        option1: "Indira Gandhi",
        option2: "Pratibha Patil",
        option3: "Sarojini Naidu",
        option4: "Sushma Swaraj",
        ans: 2,
    },
    {
        question: "Which Article of the Indian Constitution deals with the abolition of untouchability?",
        option1: "Article 19",
        option2: "Article 15",
        option3: "Article 17",
        option4: "Article 14",
        ans: 3,
    },
    {
        question: "Who is known as the 'Father of the Indian Constitution'?",
        option1: "Rajendra Prasad",
        option2: "B.R. Ambedkar",
        option3: "Jawaharlal Nehru",
        option4: "Sardar Patel",
        ans: 2,
    },
    {
        question: "Which of the following is NOT a Fundamental Right under the Indian Constitution?",
        option1: "Right to Freedom",
        option2: "Right against Exploitation",
        option3: "Right to Property",
        option4: "Right to Equality",
        ans: 3,
    },
    {
        question: "Which body conducts the UPSC Civil Services Examination?",
        option1: "State Public Service Commission",
        option2: "Staff Selection Commission",
        option3: "Union Public Service Commission",
        option4: "National Testing Agency",
        ans: 3,
    }
]